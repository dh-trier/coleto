# coleto

This is a text comparison tool writen in Python. 
